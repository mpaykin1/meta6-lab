// Звук «Острова последнего аптекаря» — только Web Audio, без файлов.
// Правило ЗВУК: гармоничное — полная громкость, диссонанс — вдвое тише; музыка развивается по настроению.
const N = {D2: 73.42, A2: 110, Bb2: 116.54, B2: 123.47, C3: 130.81, D3: 146.83, E3: 164.81, F3: 174.61,
  'F#3': 185, G2: 98, G3: 196, A3: 220, Bb3: 233.08, C4: 261.63, 'C#4': 277.18, D4: 293.66, E4: 329.63,
  F4: 349.23, 'F#4': 369.99, G4: 392, A4: 440, B4: 493.88, C5: 523.25, D5: 587.33, E5: 659.25};
const MOODS = {
  calm: {chords: [['D3', 'F#3', 'A3', 'C#4'], ['B2', 'D3', 'F#3', 'A3'], ['G2', 'B2', 'D3', 'F#3'], ['A2', 'D3', 'E3', 'A3']],
    scale: ['D4', 'E4', 'F#4', 'A4', 'B4', 'D5', 'E5'], gap: [.55, 1.7], bar: 8},
  dusk: {chords: [['D3', 'F3', 'A3', 'C4'], ['Bb2', 'D3', 'F3', 'A3'], ['G2', 'Bb2', 'D3', 'F3'], ['A2', 'C#4', 'E3', 'A3']],
    scale: ['D4', 'E4', 'F4', 'A4', 'C5', 'D5'], gap: [.8, 2.2], bar: 9},
  chase: {chords: [['D3', 'F3', 'A3', 'D4'], ['Bb2', 'D3', 'F3', 'Bb3'], ['C3', 'E3', 'G3', 'C4'], ['A2', 'C#4', 'E3', 'A3']],
    scale: ['D4', 'F4', 'A4', 'C5', 'D5'], gap: [.25, .5], bar: 4}
};

export function createAudio() {
  let ctx = null, master, music, sfx, verb, delay, rainGain, droneGain, padBus, beatGain, engineNodes = null, ducked = false;
  let landBus, underBus, forestGain, birdBus, nextBird = 0, nextBubble = 0, nextWhale = 0, birds = 1, crickets = 0, silentEl = null;
  let gateOn = true;
  let mood = 'calm', nextChord = 0, chordIx = 0, nextNote = 0, nextBeat = 0, tension = 0, enabled = true, timer = 0;
  const pads = [];
  function impulse(sec) {
    const len = ctx.sampleRate * sec, b = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    return b;
  }
  // iPhone (правило ЗВУК п.15): Web Audio молчит при беззвучном режиме и после паузы.
  // Лечим: audioSession = playback + тихий <audio> по кругу (переключает телефон в режим «медиа»),
  // и будим контекст на каждом касании.
  function silentWav() {
    const sr = 8000, n = sr / 2, b = new ArrayBuffer(44 + n * 2), v = new DataView(b);
    const w = (o, str) => [...str].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
    return URL.createObjectURL(new Blob([b], {type: 'audio/wav'}));
  }
  function unlock() {
    try { if (navigator.audioSession) navigator.audioSession.type = 'playback'; } catch (e) {}
    try {
      if (!silentEl) { silentEl = new Audio(silentWav()); silentEl.loop = true; silentEl.setAttribute('playsinline', ''); silentEl.volume = .01; }
      if (silentEl.paused) silentEl.play().catch(() => {});
    } catch (e) {}
    if (ctx && gateOn && ctx.state !== 'running') ctx.resume().catch(() => {});
  }
  for (const ev of ['touchend', 'pointerdown', 'click', 'keydown']) addEventListener(ev, () => { if (ctx) unlock(); }, {capture: true, passive: true});
  document.addEventListener('visibilitychange', () => { if (!document.hidden && ctx) unlock(); });
  function start() {
    unlock();
    if (ctx) { if (gateOn) ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC();
    // «пинок» на iOS: короткий пустой буфер внутри жеста
    try { const sb = ctx.createBufferSource(); sb.buffer = ctx.createBuffer(1, 1, 22050); sb.connect(ctx.destination); sb.start(0); } catch (e) {}
    ctx.resume().catch(() => {});
    master = ctx.createGain(); master.gain.value = enabled && gateOn ? .85 : 0;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 3;
    master.connect(comp).connect(ctx.destination);
    verb = ctx.createConvolver(); verb.buffer = impulse(2.8);
    const verbGain = ctx.createGain(); verbGain.gain.value = .35; verb.connect(verbGain).connect(master);
    delay = ctx.createDelay(1); delay.delayTime.value = .38;
    const fb = ctx.createGain(); fb.gain.value = .28; delay.connect(fb).connect(delay);
    const delayOut = ctx.createGain(); delayOut.gain.value = .3; delay.connect(delayOut).connect(master);
    landBus = ctx.createGain(); landBus.gain.value = 1; landBus.connect(master);       // суша: музыка, лес, дождь, великан
    underBus = ctx.createGain(); underBus.gain.value = 0; underBus.connect(master);     // море: подводный мир
    underBus.connect(verb);
    music = ctx.createGain(); music.gain.value = .9; music.connect(landBus); music.connect(verb);
    sfx = ctx.createGain(); sfx.gain.value = .9; sfx.connect(master); sfx.connect(verb);
    padBus = ctx.createBiquadFilter(); padBus.type = 'lowpass'; padBus.frequency.value = 1100; padBus.connect(music);
    // Дождь: шум через полосовой фильтр, тихо и мягко.
    const noise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), nd = noise.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    const rain = ctx.createBufferSource(); rain.buffer = noise; rain.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1300; bp.Q.value = .5;
    rainGain = ctx.createGain(); rainGain.gain.value = .045; rain.connect(bp).connect(rainGain).connect(landBus); rain.start();
    // Лес: шелест листвы — шум сквозь мягкий фильтр, «дышит» порывами ветра.
    forestGain = ctx.createGain(); forestGain.gain.value = 1; forestGain.connect(landBus);
    const leaves = ctx.createBufferSource(); leaves.buffer = noise; leaves.loop = true; leaves.playbackRate.value = .83;
    const lbp = ctx.createBiquadFilter(); lbp.type = 'bandpass'; lbp.frequency.value = 2400; lbp.Q.value = .6;
    const lhs = ctx.createBiquadFilter(); lhs.type = 'highshelf'; lhs.frequency.value = 5000; lhs.gain.value = -10;
    const gust = ctx.createGain(); gust.gain.value = .03;
    const gl = ctx.createOscillator(), glg = ctx.createGain(); gl.frequency.value = .09; glg.gain.value = .022; gl.connect(glg).connect(gust.gain); gl.start();
    const gl2 = ctx.createOscillator(), gl2g = ctx.createGain(); gl2.frequency.value = .23; gl2g.gain.value = .009; gl2.connect(gl2g).connect(gust.gain); gl2.start();
    leaves.connect(lbp).connect(lhs).connect(gust).connect(forestGain); leaves.start();
    birdBus = ctx.createGain(); birdBus.gain.value = 1; birdBus.connect(forestGain); birdBus.connect(verb);
    // Подводный мир: глухой гул толщи воды (слышен и в динамике телефона: 150–400 Гц), качается медленно.
    const deep = ctx.createBufferSource(); deep.buffer = noise; deep.loop = true; deep.playbackRate.value = .5;
    const dlp = ctx.createBiquadFilter(); dlp.type = 'lowpass'; dlp.frequency.value = 420; dlp.Q.value = 1.2;
    const dg = ctx.createGain(); dg.gain.value = .2;
    const dl = ctx.createOscillator(), dlg = ctx.createGain(); dl.frequency.value = .07; dlg.gain.value = .08; dl.connect(dlg).connect(dg.gain); dl.start();
    const dlf = ctx.createOscillator(), dlfg = ctx.createGain(); dlf.frequency.value = .05; dlfg.gain.value = 120; dlf.connect(dlfg).connect(dlp.frequency); dlf.start();
    deep.connect(dlp).connect(dg).connect(underBus); deep.start();
    // тихий тёплый аккорд глубины (D–A–D, гармония), чтобы вода не была пустой
    for (const [f, a] of [[146.83, .018], [220, .012], [293.66, .008]]) { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f; g.gain.value = a; o.connect(g).connect(underBus); o.start(); }
    // Дыхание великана: два низких пилообразных тона, лёгкое биение, медленный «вдох».
    droneGain = ctx.createGain(); droneGain.gain.value = 0;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 150;
    for (const f of [41.2, 41.7, 82.4]) { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.connect(lp); o.start(); }
    const breath = ctx.createOscillator(), bg = ctx.createGain(); breath.frequency.value = .11; bg.gain.value = .5;
    const breathMix = ctx.createGain(); breathMix.gain.value = .5; breath.connect(bg).connect(breathMix.gain); breath.start();
    lp.connect(breathMix).connect(droneGain).connect(landBus);
    beatGain = ctx.createGain(); beatGain.gain.value = 0; beatGain.connect(landBus);
    nextChord = nextNote = nextBeat = ctx.currentTime + .2;
    timer = setInterval(schedule, 90);
  }
  function env(g, t, a, peak, d) { g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(.0001, t + a + d); }
  function tone(freq, t, {type = 'sine', peak = .06, a = .01, d = 1.2, dest = music, echo = true} = {}) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.value = freq;
    env(g, t, a, peak, d); o.connect(g).connect(dest); if (echo) g.connect(delay); o.start(t); o.stop(t + a + d + .05);
  }
  const BIRD = [1174.66, 1318.51, 1479.98, 1760, 1975.53, 2349.32];   // D6 E6 F#6 A6 B6 D7
  function panTo(x) { const p = ctx.createStereoPanner ? ctx.createStereoPanner() : ctx.createGain(); if (p.pan) p.pan.value = x; return p; }
  function bird(t) {
    const pan = panTo(Math.random() * 1.6 - .8); pan.connect(birdBus);
    const kind = Math.random(), n = 2 + Math.floor(Math.random() * 5), base = BIRD[Math.floor(Math.random() * BIRD.length)];
    const vol = (.018 + Math.random() * .02) * birds;
    for (let i = 0; i < n; i++) {
      const tt = t + i * (kind < .5 ? .11 : .17), f = kind < .5 ? base * (i % 2 ? 1.122 : 1) : BIRD[(BIRD.indexOf(base) + i) % BIRD.length];
      const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine';
      o.frequency.setValueAtTime(f * .86, tt); o.frequency.exponentialRampToValueAtTime(f, tt + .035); o.frequency.exponentialRampToValueAtTime(f * (kind < .5 ? .95 : 1.06), tt + .09);
      env(g, tt, .008, vol, .1); o.connect(g).connect(pan); o.start(tt); o.stop(tt + .14);
    }
  }
  function cricket(t) {   // сумерки: сверчки — тихо (высокий звук должен быть мягким)
    const pan = panTo(Math.random() * 1.4 - .7); pan.connect(forestGain);
    for (let i = 0; i < 6; i++) { const tt = t + i * .055, o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = 4400; env(g, tt, .004, .006 * crickets, .03); o.connect(g).connect(pan); o.start(tt); o.stop(tt + .05); }
  }
  function bubbles(t) {
    const pan = panTo(Math.random() * 1.6 - .8); pan.connect(underBus);
    const n = Math.random() < .3 ? 3 + Math.floor(Math.random() * 5) : 1;
    for (let i = 0; i < n; i++) {
      const tt = t + i * (.05 + Math.random() * .08), f = 380 + Math.random() * 420;
      const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine';
      o.frequency.setValueAtTime(f, tt); o.frequency.exponentialRampToValueAtTime(f * 2.2, tt + .07);
      env(g, tt, .004, .05, .08); o.connect(g).connect(pan); o.start(tt); o.stop(tt + .1);
    }
  }
  function whale(t) {     // пение глубины: медленные глиссандо по нотам D-минора
    const path = [[N.A3, 0], [N.D4, 1.1], [N.F4 * .5 * 2, 2.1], [N.D4, 3.2]];
    const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter(); o.type = 'triangle'; f.type = 'lowpass'; f.frequency.value = 900;
    path.forEach(([fr, dt], i) => i ? o.frequency.exponentialRampToValueAtTime(fr * .5 * 2, t + dt) : o.frequency.setValueAtTime(fr, t));
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.045, t + .8); g.gain.setTargetAtTime(0, t + 2.8, .5);
    o.connect(f).connect(g).connect(underBus); o.start(t); o.stop(t + 5);
  }
  function chord(t) {
    const m = MOODS[mood], c = m.chords[chordIx++ % m.chords.length];
    pads.splice(0).forEach(p => { p.g.gain.cancelScheduledValues(t); p.g.gain.setTargetAtTime(0, t, .9); p.o.stop(t + 4); });
    c.forEach((n, i) => {
      for (const det of [-5, 5]) {
        const o = ctx.createOscillator(), g = ctx.createGain(); o.type = i % 2 ? 'triangle' : 'sine';
        o.frequency.value = N[n]; o.detune.value = det; g.gain.value = 0;
        g.gain.setTargetAtTime(.026, t, 1.4); o.connect(g).connect(padBus); o.start(t); pads.push({o, g});
      }
    });
    return m.bar;
  }
  function schedule() {
    if (!ctx) return;
    const now = ctx.currentTime, m = MOODS[mood];
    while (nextChord < now + .3) nextChord += chord(nextChord);
    while (nextNote < now + .3) {
      const n = m.scale[Math.floor(Math.random() * m.scale.length)];
      if (Math.random() < .82) tone(N[n], nextNote, {peak: mood === 'chase' ? .035 : .055, d: mood === 'chase' ? .5 : 1.6});
      nextNote += m.gap[0] + Math.random() * (m.gap[1] - m.gap[0]);
    }
    // Птицы: короткие напевы из пентатоники (гармонично), каждая птица со своего места в стерео.
    while (nextBird < now + .3) {
      if (!ducked && birds > .05 && mood !== 'chase') bird(nextBird);
      if (!ducked && crickets > .05) cricket(nextBird + .4);
      nextBird += 1.2 + Math.random() * 3.5;
    }
    // Под водой: пузыри и далёкое пение глубины.
    if (ducked) {
      while (nextBubble < now + .3) { bubbles(nextBubble); nextBubble += .5 + Math.random() * 2.2; }
      while (nextWhale < now + .3) { whale(nextWhale); nextWhale += 9 + Math.random() * 9; }
    } else { nextBubble = now + 1; nextWhale = now + 4; }
    // Сердцебиение в погоне: темп растёт с напряжением.
    while (nextBeat < now + .3) {
      const bpm = 64 + tension * 66;
      if (mood === 'chase') { tone(55, nextBeat, {peak: .22, d: .22, dest: beatGain, echo: false}); tone(52, nextBeat + .2, {peak: .14, d: .2, dest: beatGain, echo: false}); }
      nextBeat += 60 / bpm;
    }
  }
  return {
    start,
    get enabled() { return enabled; },
    setEnabled(v) { enabled = v; if (master) master.gain.setTargetAtTime(v && gateOn ? .85 : 0, ctx.currentTime, .2); },
    // Платформа (Playgama): пауза, реклама, вкладка свёрнута, звук выключен платформой — полная тишина.
    setGate(on) {
      gateOn = !!on; if (!ctx) return;
      master.gain.setTargetAtTime(enabled && gateOn ? .85 : 0, ctx.currentTime, .05);
      if (gateOn) ctx.resume().catch(() => {}); else setTimeout(() => { if (!gateOn) ctx.suspend().catch(() => {}); }, 120);
      try { if (silentEl) { if (gateOn) silentEl.play().catch(() => {}); else silentEl.pause(); } } catch (e) {}
    },
    get gate() { return gateOn; },
    setMood(v) { if (v !== mood && MOODS[v]) { mood = v; if (ctx) nextChord = ctx.currentTime + .05; } },
    setLevels({robot = 0, chase = 0, rain = .5, dusk = 0} = {}) {
      if (!ctx) return; tension = chase;
      birds = Math.max(0, 1 - dusk * 1.4); crickets = Math.max(0, dusk * 1.6 - .3);
      droneGain.gain.setTargetAtTime(.05 + robot * .16, ctx.currentTime, .4);
      beatGain.gain.setTargetAtTime(chase ? 1 : 0, ctx.currentTime, .3);
      rainGain.gain.setTargetAtTime(.03 + rain * .05, ctx.currentTime, .6);
    },
    chime(kind = 0) {
      if (!ctx) return; const t = ctx.currentTime, base = [N.D5, N.A4, N.E5][kind % 3];
      [1, 1.5, 2].forEach((r, i) => tone(base * r / (i === 2 ? 1.5 : 1), t + i * .09, {peak: .07, d: 1.1, dest: sfx}));
    },
    dust() {
      if (!ctx) return; const t = ctx.currentTime;
      const src = ctx.createBufferSource(), b = ctx.createBuffer(1, ctx.sampleRate * .8, ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
      const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 2200;
      const g = ctx.createGain(); g.gain.value = .12; src.buffer = b; src.connect(f).connect(g).connect(sfx); src.start(t);
      [N.A4, N.D5, N['F#4'] * 2].forEach((n, i) => tone(n, t + .1 + i * .12, {peak: .05, d: 1.4, dest: sfx}));
    },
    // Диссонанс (тритон) — вдвое тише гармоничных звуков.
    stab() {
      if (!ctx) return; const t = ctx.currentTime;
      [N.D3, N.D3 * Math.SQRT2, N.D4].forEach(f => tone(f, t, {type: 'sawtooth', peak: .02, a: .02, d: .9, dest: sfx, echo: false}));
    },
    // Мотор машины: мягкий низкий гул (две близкие частоты + фильтр), громкость и высота — от скорости.
    engine(level = 0, pitch = 0) {
      if (!ctx) return;
      if (!engineNodes) {
        const g = ctx.createGain(); g.gain.value = 0;
        const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 700; lp.Q.value = 1.4;
        // слышно и в динамике телефона: основной тон ~65–110 Гц + гармоники 130–450 Гц
        const base = [[64, 'sawtooth', .5], [64.6, 'sawtooth', .4], [128.4, 'square', .12], [192.5, 'triangle', .2]];
        const oscs = base.map(([f, type, a]) => { const o = ctx.createOscillator(), og = ctx.createGain(); o.type = type; o.frequency.value = f; og.gain.value = a; o.connect(og).connect(lp); o.start(); return o; });
        // «тарахтение» поршней: амплитуда качается с частотой оборотов
        const am = ctx.createGain(); am.gain.value = .75;
        const rpm = ctx.createOscillator(), rg = ctx.createGain(); rpm.frequency.value = 11; rg.gain.value = .25; rpm.connect(rg).connect(am.gain); rpm.start();
        // шорох выхлопа: шум вокруг 250 Гц
        const nb = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate), nd = nb.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
        const ns = ctx.createBufferSource(); ns.buffer = nb; ns.loop = true; const nbp = ctx.createBiquadFilter(); nbp.type = 'bandpass'; nbp.frequency.value = 260; nbp.Q.value = 1.1;
        const ng = ctx.createGain(); ng.gain.value = .35; ns.connect(nbp).connect(ng).connect(am); ns.start();
        lp.connect(am).connect(g).connect(sfx); engineNodes = {g, lp, oscs, rpm, base};
      }
      const t = ctx.currentTime;
      engineNodes.g.gain.setTargetAtTime(level * .34, t, .3);
      engineNodes.lp.frequency.setTargetAtTime(520 + pitch * 700, t, .3);
      engineNodes.rpm.frequency.setTargetAtTime(10 + pitch * 14, t, .4);
      engineNodes.oscs.forEach((o, i) => o.frequency.setTargetAtTime(engineNodes.base[i][0] * (1 + pitch * .6), t, .4));
    },
    // Всплеск: шум сквозь мягкий фильтр + низкий «бульк».
    splash(k = 1) {
      if (!ctx) return; const t = ctx.currentTime;
      const src = ctx.createBufferSource(), b = ctx.createBuffer(1, ctx.sampleRate * 1.6, ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 2);
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(2600, t); f.frequency.exponentialRampToValueAtTime(300, t + 1.4);
      const g = ctx.createGain(); g.gain.value = .16 * k; src.buffer = b; src.connect(f).connect(g).connect(sfx); src.start(t);
      tone(90, t, {type: 'sine', peak: .12 * k, a: .01, d: .5, dest: sfx, echo: false});
      tone(N.A4, t + .25, {peak: .03 * k, d: 1.6, dest: sfx});
    },
    // Приглушить остров, пока играет подводный город (у него своя музыка).
    duck(on) {   // под водой: суша (музыка, лес, дождь) уходит, звучит подводный мир
      ducked = !!on; if (!ctx) return; const t = ctx.currentTime;
      landBus.gain.setTargetAtTime(on ? 0 : 1, t, .8); underBus.gain.setTargetAtTime(on ? 1 : 0, t, .8);
      if (master) master.gain.setTargetAtTime(enabled && gateOn ? .85 : 0, t, .3);
    },
    // Крик аптекаря из батискафа: слышим, но не видим. Глухой — как сквозь металл и воду.
    scream() {
      if (!ctx) return; const t = ctx.currentTime;
      if (master) master.gain.setTargetAtTime(enabled && gateOn ? .85 : 0, t, .05);
      const o = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sawtooth'; o2.type = 'sawtooth'; o2.detune.value = 18;
      o.frequency.setValueAtTime(240, t); o.frequency.linearRampToValueAtTime(410, t + .35); o.frequency.linearRampToValueAtTime(330, t + 1.3); o.frequency.exponentialRampToValueAtTime(120, t + 2.4);
      o2.frequency.setValueAtTime(240, t); o2.frequency.linearRampToValueAtTime(400, t + .35); o2.frequency.linearRampToValueAtTime(320, t + 1.3); o2.frequency.exponentialRampToValueAtTime(110, t + 2.4);
      const vib = ctx.createOscillator(), vg = ctx.createGain(); vib.frequency.value = 6.5; vg.gain.value = 14; vib.connect(vg); vg.connect(o.frequency); vg.connect(o2.frequency);
      const f1 = ctx.createBiquadFilter(); f1.type = 'bandpass'; f1.frequency.value = 820; f1.Q.value = 4;
      const f2 = ctx.createBiquadFilter(); f2.type = 'bandpass'; f2.frequency.value = 1350; f2.Q.value = 5;
      const muff = ctx.createBiquadFilter(); muff.type = 'lowpass'; muff.frequency.value = 1700;
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.2, t + .08); g.gain.setTargetAtTime(.14, t + .5, .4); g.gain.exponentialRampToValueAtTime(.0001, t + 2.6);
      o.connect(f1); o2.connect(f2); f1.connect(muff); f2.connect(muff); muff.connect(g).connect(sfx);
      [o, o2, vib].forEach(x => { x.start(t); x.stop(t + 2.7); });
      tone(N.D2, t + .05, {type: 'sine', peak: .2, a: .02, d: 3.5, dest: sfx, echo: false});   // глухой удар по корпусу
    },
    door() { if (ctx) { const t = ctx.currentTime; tone(70, t, {peak: .25, d: .35, dest: sfx, echo: false}); tone(N.D4, t + .25, {peak: .05, d: 2, dest: sfx}); tone(N.A4, t + .4, {peak: .045, d: 2.2, dest: sfx}); } },
    step(v = .5) { if (ctx) tone(90 + Math.random() * 30, ctx.currentTime, {type: 'triangle', peak: .012 * v, a: .002, d: .07, dest: sfx, echo: false}); },
    // Голос великана: синтез речи, если в системе есть русский голос; поверх — тихий металлический гул.
    voice(text) {
      if (!ctx || !enabled) return;
      const t = ctx.currentTime;
      tone(N.D2, t, {type: 'square', peak: .015, a: .05, d: 1.6, dest: sfx, echo: false});
      tone(N.D2 * 1.5, t + .05, {type: 'square', peak: .03, a: .05, d: 1.6, dest: sfx, echo: false});
      try {
        const sp = window.speechSynthesis; if (!sp) return;
        const u = new SpeechSynthesisUtterance(text.toLowerCase());
        u.lang = 'ru-RU'; u.pitch = .05; u.rate = .78; u.volume = .9;
        const ru = sp.getVoices().find(v => v.lang?.startsWith('ru')); if (ru) u.voice = ru; else return;
        sp.cancel(); sp.speak(u);
      } catch (e) {}
    }
  };
}

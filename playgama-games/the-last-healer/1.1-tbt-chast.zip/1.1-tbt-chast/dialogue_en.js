// The Last Healer — English script (default language). Russian lives in dialogue.js.
// Same keys as dialogue.js: a = the healer, i = Iva, v = the Voice (machine).
export const SPEAKERS = {
  a: {name: 'Healer', color: '#a8763a'},
  i: {name: 'Iva', color: '#4f7896'},
  v: {name: 'Voice', color: '#c4532c', machine: true}
};

export const SCRIPT = {
  AT_shop: [
    ['i', 'Why does the cross on the shop glow? There’s no power anywhere.'],
    ['a', 'There is here. It comes up from under the ground, from the station. Forty years and it never went out.']
  ],
  IVA_implant: [
    ['a', 'You were shaking again last night.'],
    ['i', 'I don’t remember anything…'],
    ['a', 'You walked to the door. Eyes open, but you couldn’t hear me. The light behind your ear was orange.'],
    ['i', 'That’s the implant. They put it in when I was four. A part from some old machine.'],
    ['a', 'So, a deal: we’re back here before dark. While the light is green, you’re with me.']
  ],
  AT_bench: [
    ['i', 'The bench faces the forest. Who used to sit here?'],
    ['a', 'My teacher. The station’s last doctor. He had an iron heart.'],
    ['a', 'It stopped before the living one did. Iron doesn’t hurt — so nobody notices when it dies.']
  ],
  AT_car: [
    ['i', 'The car is in one piece! On the mainland you’d get ten arms for it.'],
    ['a', 'There they build arms out of anything. Tractors. War machines.'],
    ['i', 'Our neighbour has an arm from a war machine. At night it makes a fist all by itself.'],
    ['a', '…By itself? Remember that, Iva. It matters.']
  ],
  RIDE_ask: [['a', 'Want to go for a ride?']],
  RIDE_askAgain: [['a', 'Shall we go for a ride?']],
  RIDE_no: [['i', 'No. Let’s keep going.']],
  RIDE_go: [
    ['i', 'Yes!'],
    ['a', 'Get in. Hold on tight.']
  ],
  RIDE_drive: [
    ['i', 'We’re driving to the sea… Can a car even swim?'],
    ['a', 'This one can.']
  ],
  RIDE_driveAgain: [
    ['i', 'Back to the sea? It’s cold down there.'],
    ['a', 'The city is waiting below. The car remembers it better than I do.']
  ],
  SEA_in: [
    ['i', 'Windows in the water! And the fish glow like my herbs.'],
    ['a', 'Down there is a sunken city. Find the lights with the sonar, I’ll steer.']
  ],
  SEA_tower: [
    ['i', 'A bell tower! Did someone ring a bell under the water?'],
    ['a', 'They say the station was built over an old city. I thought it was a fairy tale.']
  ],
  SEA_galleon: [
    ['i', 'The ship is lying on its side. Like the giant in the forest.'],
    ['a', 'Everything big here fell once. And nobody picked it up.']
  ],
  SEA_chest: [
    ['i', 'A chest! Maybe there’s medicine inside?'],
    ['a', 'Medicine isn’t kept in chests. It’s kept in people. Like your little light.']
  ],
  SEA_angler: [
    ['i', 'That fish has a lantern. Like the one behind my ear.'],
    ['a', 'Don’t look at it for long. It calls, like the giant does.']
  ],
  SEA_drone: [
    ['i', 'A little machine is swimming after us.'],
    ['a', 'It’s older than the station. And it watches the way he does.']
  ],
  SEA_tent: [
    ['i', 'Tentacles… Do they move by themselves?'],
    ['a', 'By themselves. Like the neighbour’s arm at night. Don’t swim close.']
  ],
  SEA_mines: [
    ['i', 'Iron balls with spikes. Are those toys?'],
    ['a', 'That’s what they used to cure wars with. Go around.']
  ],
  SEA_ask1: [['i', 'Can we go home now?']],
  SEA_ask2: [['i', 'The light behind my ear is blinking… Can we go home now?']],
  SEA_ask3: [['i', 'I’m cold. It’s getting dark. Can we go home now?']],
  SEA_stay1: [['a', 'A little longer. There’s so much here.']],
  SEA_stay2: [['a', 'One last lap. I promise.']],
  SEA_home: [
    ['a', 'All right. Home. Let’s find the way to the shore — where we drove into the water.'],
    ['i', 'There’s a light up there! That’s the shore.']
  ],
  SEA_up: [['a', 'Surfacing. Hold on.']],
  SURFACE: [
    ['i', 'The car is a car again!'],
    ['a', 'It always comes back home. Like us.']
  ],
  SEA_night: [
    ['a', 'Iva… your implant is glowing red.'],
    ['a', 'We have to go back. Now.'],
    ['i', 'It’s too late.']
  ],
  AT_lamp: [
    ['i', 'The lamp is on in the daytime. Who lit it?'],
    ['a', 'Nobody. It lights up when you walk past. It didn’t use to.']
  ],
  AT_sign: [
    ['i', 'What does the sign say? The letters are worn off.'],
    ['a', '“Greenhouse” and “Block P”. I found the greenhouse. Never Block P.'],
    ['i', 'Is P for “patients”?'],
    ['a', 'Or “plant nursery”. Or something I’d rather not think about.']
  ],
  AT_shroomsRed: [
    ['i', 'Orange mushrooms. They don’t glow.'],
    ['a', 'Those are for eating. Medicine on this island always glows. As if someone marked it.']
  ],
  AT_deer: [
    ['i', 'The deer is just standing there, looking at the giant. Like it’s on guard.'],
    ['a', 'Animals can tell he isn’t completely dead. So can I, to be honest.']
  ],
  AT_robot: [
    ['i', 'What… who is that?'],
    ['a', 'A war machine. It fell here long before me. Don’t go near it.'],
    ['i', 'It’s humming. Can you hear it?'],
    ['a', 'Wind in the iron.'],
    ['i', 'No. It’s calling. “Patient number one”… That’s what they called me at the hospital on the mainland.'],
    ['a', 'Iva! Look at me. Breathe in. Breathe out.'],
    ['i', '…It’s gone. But the light behind my ear went warm.']
  ],
  AT_shrine: [
    ['a', 'The station’s stone gate. The road to the labs started here.'],
    ['i', 'And where does it lead now?'],
    ['a', 'Into the ground. Right under the giant. Strange, isn’t it?']
  ],
  AT_bridge: [
    ['i', 'There’s steam under the bridge! The water is warm.'],
    ['a', 'The stream runs out from under the giant. It doesn’t freeze even in winter.'],
    ['i', 'Dead things don’t warm the water.']
  ],
  AT_mill: [
    ['i', 'The mill is turning, but there’s no wind.'],
    ['a', 'It’s not the wind. There’s a pump under it — it waters the greenhouse by itself. For forty years.'],
    ['i', 'Everything here runs by itself. As if someone is taking care of the island.']
  ],
  AT_fox: [
    ['i', 'A fox! She isn’t afraid of us.'],
    ['a', 'Her mother got caught in a trap. I treated the paw with hushleaf. Animals remember who healed them.'],
    ['i', 'And people?'],
    ['a', 'People from the mainland sail over in secret. Over there herbs are a thing of the past — it’s shameful to heal “like savages”.']
  ],
  AT_hut: [
    ['i', 'Smoke from the chimney. Does someone live here?'],
    ['a', 'I dry herbs here. It was the station gardener’s lodge.'],
    ['i', 'Where’s the gardener?'],
    ['a', 'Sailed to the mainland for new lungs. Never came back. They say those lungs are still breathing — without him.']
  ],
  AT_pier: [
    ['i', 'Do the boats from the mainland dock here?'],
    ['a', 'Every few days. They bring oil, cloth, old parts. They take medicine away.'],
    ['a', 'Sometimes a man comes who is half iron. And still it’s the living half that hurts.']
  ],
  AT_boat: [
    ['i', 'This is the boat that brought me.'],
    ['a', 'You didn’t say a word the whole way, just held on to the side. The fisherman said you weren’t pulled home — you were pulled here, to the island.'],
    ['i', 'And I was holding a box. With a red cross. I never opened it for you.']
  ],
  AT_islet: [
    ['i', 'There’s just one fir tree on that little island.'],
    ['a', 'Birds brought the seeds. Everything alive here was planted by the station people once. Even the fir trees.']
  ],
  SEE_herb: [
    ['i', 'Look, the grass is glowing!'],
    ['a', 'Hushleaf. Cut it at the root, don’t pull — it’ll grow back.']
  ],
  SEE_shroom: [
    ['i', 'The blue caps are glowing!'],
    ['a', 'Dreamcap. Don’t sniff it — the spores put you to sleep for a few breaths.']
  ],
  herb1: [['a', 'It calms the nerves. Living ones, for sure. Yours… I hope.']],
  herb2: [
    ['i', 'It smells like rain. Why does it glow?'],
    ['a', 'The station scientists changed the seeds so the medicine could be seen at night. They never wrote who it was for.']
  ],
  herb3: [
    ['i', 'If I start shaking again tonight… will you give me hushleaf?'],
    ['a', 'I will. But hushleaf heals a person. And it isn’t a person that makes you shake.']
  ],
  shroom1: [['a', 'I’ll carry these myself. If anything happens, these spores will stop anyone.']],
  shroom2: [
    ['i', 'It’s like you’re getting ready for something.'],
    ['a', 'I’m a healer. I’m always getting ready.']
  ],
  water: [
    ['a', 'Clean. No machine dust here.'],
    ['i', 'Is there some on the mainland?'],
    ['a', 'People who take old machines apart get shaking hands and rotting skin. My herbs take away the pain. Not the cause.'],
    ['i', 'The light behind my ear is blinking… The sky is getting dark.'],
    ['a', 'Home. Stay close.']
  ],
  dusk1: [
    ['i', 'The light behind my ear is blinking faster. That’s bad, isn’t it?'],
    ['a', 'It means the sun is setting. Let’s hurry.']
  ],
  dusk2: [
    ['a', 'It’s blinking faster and faster. It’s going to start soon.'],
    ['i', 'If I… do it again… will you hit me?'],
    ['a', 'Never. I’ll run. I run pretty well for an old man.']
  ],
  tell: [
    ['v', 'PATIENT NUMBER ONE. FIND THE DOCTOR.'],
    ['a', 'Iva?.. Iva, look at me!'],
    ['v', 'DOCTOR LOCATED. BEGINNING DELIVERY.'],
    ['a', 'That isn’t you. To the shop, old man, run!']
  ],
  tellLate: [
    ['i', 'Too late… he’s already here…'],
    ['v', 'PATIENT NUMBER ONE. FIND THE DOCTOR.'],
    ['a', 'We didn’t make it. To the shop, run!']
  ],
  hint: [['a', 'If she grabs me — dreamcap spores. Just don’t waste them.']],
  grab: [
    ['v', 'FOLLOW ME, DOCTOR.'],
    ['a', 'Let go! Iva, wake up!']
  ],
  dust: [['a', 'Sorry, little one. Sleep.']],
  breakFree: [['a', 'I’m free… I’m sorry, I’m sorry.']],
  caught: [['v', 'DOCTOR. YOU ARE 83 YEARS LATE.']],
  caughtAfter: [['a', '…Back at the giant again. Eighty-three years? Once more — to the shop!']],
  faint: [
    ['v', 'POWER… INSUFFICIENT…'],
    ['a', 'Iva! …She’s breathing. The light went out. Carry her home, old man.']
  ],
  home: [['a', 'The bolt! Got it…']],
  ending: [
    ['i', 'Again? Was I… chasing you?'],
    ['a', 'You were leading me. Into the forest. To him.'],
    ['i', 'The voice said you were late. Eighty-three years late.'],
    ['a', 'Machines don’t joke. They only make mistakes.'],
    ['i', 'Here’s the box they brought me with. There’s a note inside.'],
    ['i', '“Don’t heal her. Heal the one lying in the forest.”'],
    ['a', '…So the giant isn’t a war machine. Tomorrow we go to the station archive.']
  ]
};

export const CHASE_BARKS = [
  ['v', 'DOCTOR, PROCEED TO THE OPERATING ROOM.'],
  ['a', 'Iva, it’s me! You know me!'],
  ['v', 'THE PATIENTS ARE WAITING.'],
  ['v', 'RESISTANCE IS NOT IN THE PROTOCOL.'],
  ['a', 'Go around her, old man, go around!']
];

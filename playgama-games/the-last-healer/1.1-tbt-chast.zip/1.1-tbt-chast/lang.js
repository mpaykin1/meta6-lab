// Язык игры (Playgama 3.4): английский по умолчанию, русский — если платформа говорит «ru».
// window.PG выставляет index.html после bridge.initialize(); без платформы — английский.
import * as RU from './dialogue.js';
import * as EN from './dialogue_en.js';

export const LANG = (window.PG && window.PG.lang === 'ru') ? 'ru' : 'en';
const D = LANG === 'ru' ? RU : EN;
export const SPEAKERS = D.SPEAKERS, SCRIPT = D.SCRIPT, CHASE_BARKS = D.CHASE_BARKS;

const STR = {
  en: {
    title: 'The Last Healer', menu: 'Menu', dust: 'Dreamcap spores', yes: 'Yes', no: 'No',
    resume: 'Resume', sound: 'Sound', on: 'on', off: 'off', restart: 'Start over', controls: 'Controls',
    controlsText: 'Phone: left half of the screen — walk (the joystick appears under your finger), right half — turn the camera. The mushroom button — dreamcap spores.<br>PC: WASD / arrows — walk, mouse — camera, wheel — zoom, Space — spores. If Iva grabs you — wiggle left and right fast. In the bathyscaphe: steer with the joystick, the round button — sonar.',
    heard: 'What we heard', about: 'About',
    aboutText: 'The Last Healer · Chapter I “Hushleaf”. An island in the fog, the last man who still heals with herbs, and Iva with a machine in her ear.',
    chapter: 'Chapter I · Hushleaf',
    intro: 'People forgot how to heal and swap what hurts for iron. On a foggy island lives the last one who still remembers the herbs. Today Iva goes into the forest with him.',
    start: 'Start', endEyebrow: 'End of the demo · Chapter I', endTitle: '“Heal the one lying in the forest”',
    endText: 'The giant was not made for war. What is hidden under it — in Chapter II, “The Station Archive”.', again: 'Play again',
    seaTitle: 'Sunken City', failed: 'The game could not start: '
  },
  ru: {
    title: 'The Last Healer', menu: 'Меню', dust: 'Пыльца сонника', yes: 'Да', no: 'Нет',
    resume: 'Продолжить', sound: 'Звук', on: 'вкл', off: 'выкл', restart: 'Начать заново', controls: 'Управление',
    controlsText: 'Телефон: левая половина экрана — идти (джойстик появляется под пальцем), правая — повернуть камеру. Кнопка с грибом — пыльца сонника.<br>ПК: WASD / стрелки — идти, мышь — камера, колёсико — приблизить, Пробел — пыльца. Если Ива схватила — быстро дёргай влево‑вправо. В батискафе: джойстик — плыть, круглая кнопка — сонар.',
    heard: 'Что слышали', about: 'Об игре',
    aboutText: 'The Last Healer — Остров последнего аптекаря · Глава I «Тихолист». Остров в тумане, последний, кто лечит травами, и Ива с машиной за ухом.',
    chapter: 'Остров последнего аптекаря · Глава I',
    intro: 'Люди разучились лечить и меняют больное на железное. На острове в тумане живёт последний, кто помнит травы. Сегодня с ним в лес идёт Ива.',
    start: 'Начать', endEyebrow: 'Конец демо · Глава I', endTitle: '«Вылечи того, кто лежит в лесу»',
    endText: 'Великан не был создан для войны. Что спрятано под ним — узнаем в главе II «Архив станции».', again: 'Ещё раз',
    seaTitle: 'Затонувший город', failed: 'Игра не запустилась: '
  }
};
export const UI = STR[LANG];

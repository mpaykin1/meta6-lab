// Playgama Bridge: пауза/звук платформы, game_ready, межстраничная реклама — только в естественных паузах.
// Реклама «максимально ненавязчиво»: только interstitial, без баннеров и без rewarded;
// показываем лишь на концовках и перезапусках (Bridge сам решает, показать ли и как часто —
// в playgama-bridge-config.json пауза между рекламами 180 с).
const B = window.bridge && window.PG && window.PG.bridgeOk ? window.bridge : null;

export function createPlatform({onPause, onAudio}) {
  let platformPause = false, adOpen = false, platformMute = false, hidden = false;
  const apply = () => onPause(platformPause || adOpen || hidden);
  const sound = () => onAudio(!platformMute && !adOpen && !hidden && !platformPause);
  if (B) {
    try { platformMute = B.platform.isAudioEnabled === false; } catch (e) {}
    try { B.platform.on(B.EVENT_NAME.PAUSE_STATE_CHANGED, p => { platformPause = !!p; apply(); sound(); }); } catch (e) {}
    try { B.platform.on(B.EVENT_NAME.AUDIO_STATE_CHANGED, on => { platformMute = !on; sound(); }); } catch (e) {}
    try {
      B.advertisement.on(B.EVENT_NAME.INTERSTITIAL_STATE_CHANGED, st => {
        adOpen = st === 'opened' || st === 'loading'; apply(); sound();
      });
    } catch (e) {}
  }
  // свернули вкладку — тишина и пауза (Playgama 3.3.5)
  document.addEventListener('visibilitychange', () => { hidden = document.hidden; apply(); sound(); });
  return {
    get muted() { return platformMute; },
    sync: sound,
    ready() { try { B && B.platform.sendMessage('game_ready'); } catch (e) {} },
    ad(placement) { try { B && B.advertisement.showInterstitial(placement); } catch (e) {} },
    get bridge() { return B; }
  };
}

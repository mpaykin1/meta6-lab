// «Остров последнего аптекаря» · сцена «Машина → Батискаф» (просьба владельца 17.11.2026).
// Новый СЛОЙ поверх готовой игры (НЕ ЛОМАТЬ РАБОЧЕЕ): game.js только зовёт sea.tick / sea.reset.
// Машина — INK-модель meta6-lab preview/ink-car-bathyscaphe (REUSE), море внизу — игра «Затонувший город»
// (её копия лежит в папке sunken/ и открывается во весь экран, батискаф там заменён на эту же машину).
//
// Сюжет:
//  у машины аптекарь: «Хочешь покататься?» → игрок за Иву: Да / Нет. Нет — идут дальше, у машины спросит снова.
//  Да — садятся, мотор, машина медленно едет к морю: «Разве машина умеет плавать?» — «Эта машина умеет».
//  В воде машина превращается в батискаф → «Затонувший город». Ива иногда просит: «Может, вернёмся домой?»
//  Игрок за аптекаря: Да — свет над берегом, нашли его — всплываем, батискаф снова машина, игра на суше.
//  Нет 3 раза — ночь, имплант Ивы красный: «Нам нужно срочно вернуться» — «Уже поздно». Крик. Начало игры.
import * as T from 'three';
import {createInkCarBathyscaphe} from './ref/ink-car-bathyscaphe.js';
import {shoreX as shoreX0} from './ref/ink-world.js';
import {UI} from './lang.js';

const damp = (k, dt) => 1 - Math.exp(-k * dt);
const ease = x => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };
const angTo = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));
export const SEA_RULES = {refuseLimit: 3, firstAsk: 45, askEvery: 40, carScale: .76};

export function createSea({scene, paint, valley, coast, hero, iva, marks, ui, audio, play, busy, burst, getState, setState, onDeath}) {
  // ---------- машина: INK-модель на месте старой зелёной машины эталона ----------
  const PARK = {x: -12.3, z: -16.3, yaw: .10};
  valley.world.traverse(o => { if (o.name === 'Зелёный автомобиль') o.visible = false; });
  const car = new T.Group(); car.name = 'Машина аптекаря (INK машина → батискаф)';
  const model = createInkCarBathyscaphe(20261117);
  model.scale.setScalar(SEA_RULES.carScale); car.add(model);
  car.position.set(PARK.x, 0, PARK.z); car.rotation.y = PARK.yaw;
  scene.add(car); paint.apply(car, {seed: 'apothecary-car-bathyscaphe'});
  // Фары: тёплый ореол, разгорается, когда мотор работает (свет «размазывает» движение).
  const glowTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, '#ffffffdd'); g.addColorStop(.4, '#ffffff55'); g.addColorStop(1, '#ffffff00'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new T.CanvasTexture(c); })();
  const lamps = [-.66, .66].map(x => { const s = new T.Sprite(new T.SpriteMaterial({map: glowTex, color: '#ffe0a0', transparent: true, opacity: 0, depthWrite: false, blending: T.AdditiveBlending})); s.position.set(x, .77, 1.6); s.scale.setScalar(.9); car.add(s); return s; });

  // ---------- путь к морю: ближайшая вода от стоянки ----------
  let shore = null, dir = new T.Vector2(0, -1);
  {
    let best = 1e9;
    const inOld = (x, z) => x >= -20.5 && x <= 21 && z >= -20 && z <= 20;
    for (let a = 0; a < Math.PI * 2; a += .05) {
      const dx = Math.sin(a), dz = Math.cos(a);
      for (let r = .5; r < 26; r += .25) {
        const x = PARK.x + dx * r, z = PARK.z + dz * r;
        if (!coast.isLand(x, z)) { if (r < best) { best = r; shore = new T.Vector2(x, z); dir.set(dx, dz); } break; }
        // дома, мельница, великан на пути — это направление не годится
        if (r > 2.2 && inOld(x, z) && !valley.canWalk(x, z) && Math.abs(x - shoreX0(z)) > .6) break;
      }
    }
    if (!shore) shore = new T.Vector2(PARK.x, -24);
  }
  const SEA_PT = new T.Vector2(shore.x + dir.x * 6, shore.y + dir.y * 6);    // здесь машина уходит под воду

  // ---------- экран моря: игра «Затонувший город» во весь экран ----------
  const veil = document.createElement('div'); veil.id = 'ap-veil'; document.body.append(veil);
  const ring = document.createElement('div');
  ring.style.cssText = 'position:fixed;left:50%;top:50%;width:46px;height:46px;margin:-23px 0 0 -23px;border-radius:50%;border:2px solid #9fd4e255;border-top-color:#e8f6ff;z-index:4;opacity:0;pointer-events:none;transition:opacity .6s;animation:apspin 1.1s linear infinite';
  document.body.append(ring);
  const st = document.createElement('style'); st.textContent = '@keyframes apspin{to{transform:rotate(360deg)}}'; document.head.append(st);
  let frame = null, bridge = null, ready = false;
  function openFrame() {
    if (frame) return;
    ready = false; bridge = null;
    frame = document.createElement('iframe'); frame.id = 'sea-frame'; frame.title = UI.seaTitle;
    frame.setAttribute('allow', 'autoplay'); frame.src = 'sunken/index.html?aptekar';
    document.body.append(frame);
  }
  function closeFrame() { if (frame) { frame.remove(); frame = null; bridge = null; ready = false; } }
  addEventListener('message', e => {
    if (!frame || e.source !== frame.contentWindow || !e.data?.aptekar) return;
    const m = e.data;
    if (m.type === 'ready') { ready = true; bridge = frame.contentWindow.__aptekarBridge; bridge?.mute(!audio.enabled); }
    else if (m.type === 'tick') onTick(m);
    else if (m.type === 'reached') { if (S.phase === 'sea') play('SEA_up', null, true); }
    else if (m.type === 'surfaced') { if (S.phase === 'sea') toPhase('surface'); }
  });

  // ---------- состояние сцены ----------
  const S = {phase: 'park', t: 0, veil: 0, veilTo: 0, veilColor: '#0b1d2a', frameOp: 0, morph: 0, speed: 0, y: 0, engine: 0,
    rideReady: true, asked: false, rides: 0, refusals: 0, returning: false, askT: 0, seaSeen: {}, night: 0, red: 0, carAway: true};
  function toPhase(p) { S.phase = p; S.t = 0; }
  function hideHeroes(on) {
    hero.visible = !on; iva.group.visible = !on; marks.forEach(m => m.visible = !on);
  }
  function seatHeroes() { hero.position.set(car.position.x, 0, car.position.z); iva.group.position.copy(hero.position); }
  function askRide() {
    S.asked = true;
    play(S.rides === 0 && !S.everAsked ? 'RIDE_ask' : 'RIDE_askAgain', () => {
      if (getState() !== 'walk') return;
      ui.ask([UI.yes, UI.no], i => {
        if (i === 0) { play('RIDE_go', null, true); startRide(); }
        else { play('RIDE_no', null, true); S.rideReady = false; }
      });
    }, true);
    S.everAsked = true;
  }
  function startRide() {
    S.rideReady = false; S.rides++; S.refusals = 0; S.night = S.red = 0; S.seaSeen = {}; S.returning = false;
    setState('ride'); toPhase('board'); openFrame();
  }
  function seaAsk() {
    const n = Math.min(3, S.refusals + 1);
    play('SEA_ask' + n, () => {
      if (S.phase !== 'sea' || S.returning) return;
      ui.ask([UI.yes, UI.no], i => {
        if (S.phase !== 'sea') return;
        if (i === 0) { S.returning = true; play('SEA_home', null, true); bridge?.showExit(true); }
        else {
          S.refusals++;
          if (S.refusals >= SEA_RULES.refuseLimit) { toPhase('night'); }
          else play('SEA_stay' + Math.min(2, S.refusals), null, true);
        }
      });
    }, true);
  }
  function onTick(m) {
    if (S.phase !== 'sea' || busy() || ui.asking) return;
    for (const id of m.near || []) if (!S.seaSeen[id]) { S.seaSeen[id] = true; play('SEA_' + id); break; }
  }

  // ---------- кадр ----------
  const tmp = new T.Vector2();
  function driveTo(target, dt, maxSpeed, turn = 1.6) {
    tmp.set(target.x - car.position.x, target.y - car.position.z);
    const dist = tmp.length(), want = Math.atan2(tmp.x, tmp.y);
    car.rotation.y += angTo(car.rotation.y, want) * damp(turn, dt);
    const aligned = Math.max(.25, Math.cos(angTo(car.rotation.y, want)));
    S.speed += (Math.min(maxSpeed, dist * .9) * aligned - S.speed) * damp(1.4, dt);
    car.position.x += Math.sin(car.rotation.y) * S.speed * dt;
    car.position.z += Math.cos(car.rotation.y) * S.speed * dt;
    return dist;
  }
  function tick(dt, t, ctx) {
    S.t += dt;
    const state = getState();
    // У машины: аптекарь предлагает покататься (каждый раз, когда герои снова подходят).
    if (state === 'walk' && S.phase === 'park') {
      const d = Math.hypot(hero.position.x - PARK.x, hero.position.z - PARK.z);
      if (d > 5.5) S.rideReady = true;
      if (ui.asking && S.asked && d > 4.6) { ui.ask(null); S.rideReady = false; S.asked = false; }
      if (S.rideReady && !S.asked && ctx.flags.at_car && ctx.stage < 4 && ctx.day < .7 && d < 3.4 && !busy() && !ui.asking) askRide();
      if (!ui.asking && S.asked && !busy()) S.asked = false;
    }
    // Живая машина: даже на стоянке чуть «дышит» мотор-фары, батискаф качается на волне.
    let bob = 0;
    switch (S.phase) {
      case 'board': {   // садятся, хлопает дверь, заводится мотор
        if (S.t > .6 && hero.visible) { hideHeroes(true); audio.door(); }
        S.engine = Math.min(1, S.t / 1.5) * .6;
        if (S.t > 2.4 && !busy()) { toPhase('drive'); play(S.rides > 1 ? 'RIDE_driveAgain' : 'RIDE_drive'); }
        break;
      }
      case 'drive': {   // медленно к морю: сначала дуга разворота, потом прямо в воду
        driveTo(SEA_PT, dt, 1.7, 1.2);   // поворот по дуге: машина едет, пока разворачивается
        S.engine = .7 + Math.min(.3, S.speed * .15);
        if (!coast.isLand(car.position.x, car.position.z) && S.t > 3) {
          toPhase('sink'); audio.splash(1);
          burst(new T.Vector3(car.position.x, .2, car.position.z), '#bfe3ea', 46, 3.2);
          ctx.shake(.25);
        }
        break;
      }
      case 'sink': {    // в воде машина превращается в батискаф и уходит вниз
        driveTo(SEA_PT, dt, .9, 1.2);
        S.morph = ease(S.t / 2.6);
        S.y = -ease((S.t - 1.4) / 2.4) * 1.6;
        S.engine = .5 * (1 - ease(S.t / 3.5));
        if (Math.random() < dt * 9) burst(new T.Vector3(car.position.x + (Math.random() - .5) * 1.4, .05, car.position.z + (Math.random() - .5) * 1.4), '#d8eef2', 3, 1);
        S.veilTo = ease((S.t - 2.6) / 1.2);
        if (S.t > 4 && S.veil > .97) toPhase('load');
        break;
      }
      case 'load': {    // глубина: ждём, пока город на дне готов
        S.veilTo = 1; ring.style.opacity = ready ? 0 : 1;
        if (!ready && S.t > 30) { closeFrame(); ring.style.opacity = 0; S.frameOp = 0; toPhase('surface'); break; }   // город не загрузился — тихо всплываем
        if (ready) { audio.duck(true); ui.sea(true); toPhase('sea'); S.askT = SEA_RULES.firstAsk; play('SEA_in'); }
        break;
      }
      case 'sea': {
        S.frameOp = Math.min(1, S.frameOp + dt * 1.2); S.veilTo = 0; ring.style.opacity = 0;
        if (!S.returning && !busy() && !ui.asking && (S.askT -= dt) <= 0) { S.askT = SEA_RULES.askEvery; seaAsk(); }
        // тьма сгущается с каждым «нет»: ночь подбирается к городу
        S.night += (S.refusals / SEA_RULES.refuseLimit * .55 - S.night) * damp(.5, dt);
        bridge?.setNight(S.night);
        break;
      }
      case 'night': {   // ночь: имплант Ивы красный, «уже поздно», крик из батискафа
        if (S.t < .1) { ui.ask(null); bridge?.freeze(true); }
        S.night += (1 - S.night) * damp(.8, dt); bridge?.setNight(S.night);
        if (S.t > 1.6 && !S.lines) { S.lines = true; play('SEA_night', () => { S.lateT = 0; }, true); }
        if (S.lines) { S.red += (1 - S.red) * damp(.9, dt); bridge?.setRed(S.red); if (Math.random() < dt * 2) bridge?.glitch(.6); }
        if (S.lateT !== undefined && S.lateT !== null) {
          S.lateT += dt;
          if (S.lateT > .4) { S.veilColor = '#000'; S.veilTo = 1; S.frameOp = Math.max(0, S.frameOp - dt * 1.5); }
          if (S.lateT > 1.3 && !S.screamed) { S.screamed = true; audio.scream(); }
          if (S.lateT > 5.2) { S.lines = false; S.lateT = null; S.screamed = false; toPhase('dead'); }
        }
        break;
      }
      case 'dead': {    // конец — и игра возвращается в своё начало
        closeFrame(); audio.duck(false); ui.sea(false);
        S.veilTo = 1;
        if (S.t > .8) { restoreCar(); onDeath(); S.veilTo = 0; toPhase('park'); }
        break;
      }
      case 'surface': { // всплыли у берега: экран моря гаснет, на острове — батискаф в воде
        S.frameOp = Math.max(0, S.frameOp - dt * 1.4); S.veilTo = 1; S.veilColor = '#0b1d2a';
        if (S.frameOp <= 0 && S.veil > .97) {
          closeFrame(); audio.duck(false); ui.sea(false); ui.ask(null);
          car.position.set(SEA_PT.x, 0, SEA_PT.y); car.rotation.y = Math.atan2(-dir.x, -dir.y);
          S.morph = 1; S.y = -1.6; S.speed = 0; toPhase('emerge');
        }
        break;
      }
      case 'emerge': {  // батискаф выходит к берегу и опять становится машиной
        S.veilTo = 0;
        driveTo(shore, dt, 1, 1.4);
        S.y = -1.6 * (1 - ease(S.t / 2.6));
        S.morph = 1 - ease((S.t - .8) / 2.8);
        S.engine = .6;
        if (Math.random() < dt * 10 && S.y < -.1) burst(new T.Vector3(car.position.x, .05, car.position.z), '#d8eef2', 3, 1.2);
        if (S.t > 1.2 && !S.saidSurface) { S.saidSurface = true; audio.splash(.6); play('SURFACE'); }
        if (S.t > 3.8 && coast.isLand(car.position.x, car.position.z)) toPhase('return');
        break;
      }
      case 'return': {  // обратно на стоянку
        S.y = 0; S.morph = 0;
        if (!S.parking && Math.hypot(PARK.x - car.position.x, PARK.z - car.position.z) > .4) driveTo(new T.Vector2(PARK.x, PARK.z), dt, 1.6, 1.6);
        else {
          S.parking = true;
          car.rotation.y += angTo(car.rotation.y, PARK.yaw) * damp(2, dt); S.speed *= 1 - damp(4, dt);
          car.position.x += (PARK.x - car.position.x) * damp(3, dt); car.position.z += (PARK.z - car.position.z) * damp(3, dt);
          if (Math.abs(angTo(car.rotation.y, PARK.yaw)) < .05) {
            hideHeroes(false); audio.door();
            hero.position.set(PARK.x + 1.5, 0, PARK.z + .8); iva.group.position.set(PARK.x + 2.1, 0, PARK.z - .3);
            S.saidSurface = false; S.parking = false; S.rideReady = false; S.engine = 0; toPhase('park'); setState('walk');
          }
        }
        break;
      }
      default: S.engine = 0;
    }
    if (['board', 'drive', 'sink', 'load', 'sea', 'night', 'surface', 'emerge', 'return'].includes(S.phase)) seatHeroes();
    // машина живёт: подвеска, качка на воде, фары по мотору
    bob = S.y < -.05 || S.morph > .5 ? Math.sin(t * 1.3) * .05 : Math.sin(t * 9) * .006 * S.engine;
    car.position.y = S.y + bob;
    car.rotation.z = Math.sin(t * 1.1) * .03 * S.morph + Math.sin(t * 17) * .004 * S.engine;
    model.userData.setMorph(S.morph, t);
    lamps.forEach(l => { l.material.opacity = (.15 + S.engine * .6) * (1 - S.morph) * (.9 + .1 * Math.sin(t * 13)); l.visible = S.y > -.6; });
    audio.engine(S.phase === 'sea' || S.phase === 'load' || S.phase === 'night' || S.phase === 'dead' ? 0 : S.engine, Math.min(1, S.speed / 2));
    // экран моря и шторка
    S.veil += (S.veilTo - S.veil) * damp(S.veilTo > S.veil ? 2.2 : 1.6, dt);
    veil.style.background = S.veilColor; veil.style.opacity = S.veil.toFixed(3);
    if (frame) { frame.style.opacity = (S.phase === 'sea' || S.phase === 'night' || S.phase === 'surface' ? S.frameOp : 0).toFixed(3); frame.style.pointerEvents = S.phase === 'sea' || S.phase === 'night' ? 'auto' : 'none'; }
  }
  function restoreCar() {
    car.position.set(PARK.x, 0, PARK.z); car.rotation.set(0, PARK.yaw, 0);
    S.morph = 0; S.y = 0; S.speed = 0; S.engine = 0; hideHeroes(false);
  }
  function reset() {
    closeFrame(); ui.ask(null); ui.sea(false); audio.duck(false); restoreCar();
    Object.assign(S, {phase: 'park', t: 0, veil: 0, veilTo: 0, veilColor: '#0b1d2a', frameOp: 0, rideReady: true, asked: false, everAsked: false, rides: 0,
      refusals: 0, returning: false, seaSeen: {}, night: 0, red: 0, lines: false, parking: false, lateT: null, screamed: false, saidSurface: false});
    veil.style.opacity = 0; ring.style.opacity = 0;
  }
  return {
    tick, reset, car, shore, SEA_PT,
    get phase() { return S.phase; }, get refusals() { return S.refusals; },
    // экран моря закрывает остров целиком — остров можно не рисовать (ВИДИМО И ЭКОНОМНО)
    get covering() { return (S.phase === 'sea' && S.frameOp >= 1) || ((S.phase === 'load' || S.phase === 'dead') && S.veil > .99); },
    pause(on) { bridge?.pause(on); },
    mute(on) { bridge?.mute(on); },
    get bridge() { return bridge; }, get ready() { return ready; },
    debugRide() { startRide(); }, debugAsk() { S.askT = 0; }, debugExit() { bridge?.teleportToExit(); }
  };
}
